### Bane

*Level 1 Enchantment* (Bard, Cleric, Warlock)

**Casting Time:** Action

**Range:** 30 feet

**Components:** V, S, M (a drop of blood)

**Duration:** Concentration, up to 1 minute

Up to three creatures of your choice that you can see within range must each make a Charisma saving throw. Whenever a target that fails this save makes an attack roll or a saving throw before the spell ends, the target must subtract 1d4 from the attack roll or save.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 1.

### Banishment

*Level 4 Abjuration* (Cleric, Paladin, Sorcerer, Warlock, Wizard)

**Casting Time:** Action

**Range:** 30 feet

**Components:** V, S, M (a pentacle)

**Duration:** Concentration, up to 1 minute

One creature that you can see within range must succeed on a Charisma saving throw or be transported to a harmless demiplane for the duration. While there, the target has the Incapacitated condition. When the spell ends, the target reappears in the space it left or in the nearest unoccupied space if that space is occupied. If the target is an Aberration, a Celestial, an Elemental, a Fey, or a Fiend, the target doesn’t return if the spell lasts for 1 minute. The target is instead transported to a random location on a plane (GM’s choice) associated with its creature type.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 4.

### Barkskin

*Level 2 Transmutation* (Druid, Ranger)

**Casting Time:** Bonus Action

**Range:** Touch

**Duration:** 1 hour

You touch a willing creature. Until the spell ends, the target’s skin assumes a bark-like appearance, and the target has an Armor Class of 17 if its AC is lower than that.

### Beacon of Hope

*Level 3 Abjuration* (Cleric)

**Casting Time:** Action

**Range:** 30 feet

**Components:** V, S

**Duration:** Concentration, up to 1 minute

Choose any number of creatures within range. For the duration, each target has Advantage on Wisdom saving throws and Death Saving Throws and regains the maximum number of Hit Points possible from any healing.

### Befuddlement

*Level 8 Enchantment* (Bard, Druid, Warlock, Wizard)

**Casting Time:** Action

**Range:** 150 feet

**Components:** V, S, M (a key ring with no keys)

**Duration:** Instantaneous

You blast the mind of a creature that you can see within range. The target makes an Intelligence saving throw. On a failed save, the target takes 10d12 Psychic damage and can’t cast spells or take the Magic action. At the end of every 30 days, the target repeats the save, ending the effect on a success. The effect can also be ended by the Greater Restoration, Heal, or Wish spell. On a successful save, the target takes half as much damage only.

### Bestow Curse

*Level 3 Necromancy* (Bard, Cleric, Wizard)

**Casting Time:** Action

**Range:** Touch

**Components:** V, S

**Duration:** Concentration, up to 1 minute

You touch a creature, which must succeed on a Wisdom saving throw or become cursed for the duration. Until the curse ends, the target suffers one of the following effects of your choice: • Choose one ability. The target has Disadvantage on ability checks and saving throws made with that ability. • The target has Disadvantage on attack rolls against you. • In combat, the target must succeed on a Wisdom saving throw at the start of each of its turns or be forced to take the Dodge action on that turn. • If you deal damage to the target with an attack roll or a spell, the target takes an extra 1d8 Necrotic damage.

***Using a Higher-Level Spell Slot.*** If you cast this spell using a level 4 spell slot, you can maintain Concentration on it for up to 10 minutes. If you use a level 5+ spell slot, the spell doesn’t require Concentration, and the duration becomes 8 hours (level 5–6 slot) or 24 hours (level 7–8 slot). If you use a level 9 spell slot, the spell lasts until dispelled.

### Black Tentacles

*Level 4 Conjuration* (Wizard)

**Casting Time:** Action

**Range:** 90 feet

**Components:** V, S, M (a tentacle)

**Duration:** Concentration, up to 1 minute

Squirming, ebony tentacles fill a 20-foot square on ground that you can see within range. For the duration, these tentacles turn the ground in that area into Difficult Terrain. Each creature in that area makes a Strength saving throw. On a failed save, it takes 3d6 Bludgeoning damage, and it has the Restrained condition until the spell ends. A creature also makes that save if it enters the area or ends it turn there. A creature makes that save only once per turn. A Restrained creature can take an action to make a Strength (Athletics) check against your spell save DC, ending the condition on itself on a success.

### Blade Barrier

*Level 6 Evocation* (Cleric)

**Casting Time:** Action

**Range:** 90 feet

**Components:** V, S

**Duration:** Concentration, up to 10 minutes

You create a wall of whirling blades made of magical energy. The wall appears within range and lasts for the duration. You make a straight wall up to 100 feet long, 20 feet high, and 5 feet thick, or a ringed wall up to 60 feet in diameter, 20 feet high, and 5 feet thick. The wall provides Three-Quarters Cover, and its space is Difficult Terrain. Any creature in the wall’s space makes a Dexterity saving throw, taking 6d10 Force damage on a failed save or half as much damage on a successful one. A creature also makes that save if it enters the wall’s space or ends it turn there. A creature makes that save only once per turn.

### Bless

*Level 1 Enchantment* (Cleric, Paladin)

**Casting Time:** Action

**Range:** 30 feet

**Components:** V, S, M (a Holy Symbol worth 5+ GP)

**Duration:** Concentration, up to 1 minute

You bless up to three creatures within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target adds 1d4 to the attack roll or save.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 1.

### Blight

*Level 4 Necromancy* (Druid, Sorcerer, Warlock, Wizard)

**Casting Time:** Action

**Range:** 30 feet

**Components:** V, S

**Duration:** Instantaneous

A creature that you can see within range makes a Constitution saving throw, taking 8d8 Necrotic damage on a failed save or half as much damage on a successful one. A Plant creature automatically fails the save. Alternatively, target a nonmagical plant that isn’t a creature, such as a tree or shrub. It doesn’t make a save; it simply withers and dies.

***Using a Higher-Level Spell Slot.*** The damage increases by 1d8 for each spell slot level above 4.

### Blindness/Deafness

*Level 2 Transmutation* (Bard, Cleric, Sorcerer, Wizard)

**Casting Time:** Action

**Range:** 120 feet

**Components:** V

**Duration:** 1 minute

One creature that you can see within range must succeed on a Constitution saving throw, or it has the Blinded or Deafened condition (your choice) for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 2.

### Blink

*Level 3 Transmutation* (Sorcerer, Wizard)

**Casting Time:** Action

**Range:** Self

**Components:** V, S

**Duration:** 1 minute

Roll 1d6 at the end of each of your turns for the duration. On a roll of 4–6, you vanish from your current plane of existence and appear in the Ethereal Plane (the spell ends instantly if you are already on that plane). While on the Ethereal Plane, you can perceive the plane you left, which is cast in shades of gray, but you can’t see anything there more than 60 feet away. You can affect and be affected only by other creatures on the Ethereal Plane, and creatures on the other plane can’t perceive you unless they have a special ability that lets them perceive things on the Ethereal Plane. You return to the other plane at the start of your next turn and when the spell ends if you are on the Ethereal Plane. You return to an unoccupied space of your choice that you can see within 10 feet of the space you left. If no unoccupied space is available within that range, you appear in the nearest unoccupied space.

### Blur

*Level 2 Illusion* (Sorcerer, Wizard)

**Casting Time:** Action

**Range:** Self

**Components:** V

**Duration:** Concentration, up to 1 minute

Your body becomes blurred. For the duration, any creature has Disadvantage on attack rolls against you. An attacker is immune to this effect if it perceives you with Blindsight or Truesight.

### Burning Hands

*Level 1 Evocation* (Sorcerer, Wizard)

**Casting Time:** Action

**Range:** Self

**Components:** V, S

**Duration:** Instantaneous

A thin sheet of flames shoots forth from you. Each creature in a 15-foot Cone makes a Dexterity saving throw, taking 3d6 Fire damage on a failed save or half as much damage on a successful one. Flammable objects in the Cone that aren’t being worn or carried start burning.

***Using a Higher-Level Spell Slot.*** The damage increases by 1d6 for each spell slot level above 1.
