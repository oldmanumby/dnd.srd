### Horn of Valhalla

*Wondrous Item, Rare (Silver or Brass), Very Rare (Bronze), or Legendary (Iron)*

You can take a Magic action to blow this horn. In response, warrior spirits from the plane of Ysgard appear in unoccupied spaces within 60 feet of you. Each spirit uses the Berserker stat block and returns to Ysgard after 1 hour or when it drops to 0 Hit Points. The spirits look like living, breathing warriors, and they have Immunity to the Charmed and Frightened conditions. Once you use the horn, it can’t be used again until 7 days have passed. Four types of Horn of Valhalla are known to exist, each made of a different metal. The horn’s type determines how many spirits it summons, as well as the requirement for its use. The GM chooses the horn’s type or determines it randomly by rolling on the following table. If you blow the horn without meeting its requirement, the summoned spirits attack you. If you meet the requirement, they are Friendly to you and your allies and follow your commands.

1d100 Horn Type Spirits Requirement

01–40 Silver 2 None

41–75 Brass 3 Proficiency with all

Simple weapons

76–90 Bronze 4 Training with all

Medium armor

91–00 Iron 5 Proficiency with all

Martial weapons
