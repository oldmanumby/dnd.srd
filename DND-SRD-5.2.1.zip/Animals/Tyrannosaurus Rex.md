## Tyrannosaurus Rex

*Huge Beast (Dinosaur), Unaligned*

**AC 13 Initiative +3 (13)**

**HP 136 (13d12 + 52)**

**Speed 50 ft.**


| | MOD | SAVE | | MOD | SAVE |
|---|:---:|:---:|---|:---:|:---:|
| **Str** 25 | +7 | +10 | **Dex** 10 | +0 | +0 | **Con** 19 | +4 | +4 |
| **Int** 2 | −4 | −4 | **Wis** 12 | +1 | +4 | **Cha** 9 | −1 | −1 |

**Skills Perception +4**

**Senses Passive Perception 14**

**Languages None**

**CR 8 (XP 3,900; PB +3)**

### Actions

Multiattack. The tyrannosaurus makes one Bite attack and one Tail attack.

Bite. Melee Attack Roll: +10, reach 10 ft. Hit: 33 (4d12 + 7) Piercing damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 17). While Grappled, the target has the Restrained condition and can’t be targeted by the tyrannosaurus’s Tail.

Tail. Melee Attack Roll: +10, reach 15 ft. Hit: 25 (4d8 + 7) Bludgeoning damage. If the target is a Huge or smaller creature, it has the Prone condition.
