## Xorn

*Medium Elemental, Neutral*

**AC 19 Initiative +0 (10)**

**HP 84 (8d8 + 48)**

**Speed 20 ft., Burrow 20 ft.**


| | MOD | SAVE | | MOD | SAVE |
|---|:---:|:---:|---|:---:|:---:|
| **Str** 17 | +3 | +3 | **Dex** 10 | +0 | +0 | **Con** 22 | +6 | +6 |
| **Int** 11 | +0 | +0 | **Wis** 10 | +0 | +0 | **Cha** 11 | +0 | +0 |

**Skills Perception +6, Stealth +6**

**Immunities Poison; Paralyzed, Petrified, Poisoned**

**Senses Darkvision 60 ft., Tremorsense 60 ft.;**

Passive Perception 16 Languages Primordial (Terran)

**CR 5 (XP 1,800; PB +3)**

### Traits

Earth Glide. The xorn can burrow through nonmagical, unworked earth and stone. While doing so, the xorn doesn’t disturb the material it moves through.

Treasure Sense. The xorn can pinpoint the location of precious metals and stones within 60 feet of itself.

### Actions

Multiattack. The xorn makes one Bite attack and three

Claw attacks.

Bite. Melee Attack Roll: +6, reach 5 ft. Hit: 17 (4d6 + 3)

Piercing damage.

Claw. Melee Attack Roll: +6, reach 5 ft. Hit: 8 (1d10 + 3) Slashing damage.

### Bonus Actions

Charge. The xorn moves up to its Speed or Burrow

**Speed straight toward an enemy it can sense.**

Zombies
